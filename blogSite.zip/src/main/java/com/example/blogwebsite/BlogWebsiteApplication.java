package com.example.blogwebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlogWebsiteApplication {

    public static void main(String[] args) {
        SpringApplication.run(BlogWebsiteApplication.class, args);
    }

}
