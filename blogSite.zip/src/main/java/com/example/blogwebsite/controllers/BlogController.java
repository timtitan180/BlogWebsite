package com.example.blogwebsite.controllers;


import com.example.blogwebsite.entities.Blog;
import com.example.blogwebsite.repositories.BlogRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;


@Controller
public class BlogController {

    public static final Logger LOG = LoggerFactory.getLogger(BlogController.class);

    @Autowired
    BlogRepository blogRepository;

    @GetMapping(value = "/blogs")
    public ModelAndView showBlogs (@ModelAttribute("Blogs") Blog blog) {
        ModelAndView blogPage = new ModelAndView("blogs");
        List<Blog> blogs = (List<Blog>) blogRepository.findAll();
        blogPage.addObject("blogs",blogs);
        return blogPage;
    }

    @GetMapping(value="blogs/createblog")
        public ModelAndView getBlogPage() {
            return new ModelAndView("blogs");
    }

    @PostMapping(value = "blogs/createblog")
        public ModelAndView createBlog (@ModelAttribute("Blogs") Blog blog) {
            ModelAndView blogPage = new ModelAndView("blogs");
            Blog newBlog = new Blog();
            newBlog.setBlogTitle(blog.getBlogTitle());
            newBlog.setBlogBody(blog.getBlogBody());
            blogRepository.save(newBlog);
            LOG.info("Blog Saved Successfully!");
            blogPage.addObject("message","Blog Saved!");
            blogPage.addObject("blogs",newBlog);
            blogPage.addObject("id",blog.getId());
            return blogPage;
        }

    @GetMapping("blogs/edit/{id}")
    public ModelAndView editBlogs (@ModelAttribute("Blogs") Blog blog, @PathVariable(name="id") Integer id) {
        ModelAndView page = new ModelAndView("editBlogs");
//        Blog blogtoEdit = blogRepository.findById(id);
        LOG.info("Editing Blog...");
        page.addObject("blog", blog);
        return page;
    }

    @DeleteMapping("/blogs/delete/{id}")
    public String deleteBlog (@PathVariable(name = "id") Integer id) {
        ModelAndView page = new ModelAndView("blogs");
        blogRepository.deleteById(id);
        LOG.info("Blog has been deleted");
        page.addObject("id", id);
        page.addObject("message","Blog has been deleted");
        return "redirect:/blogs";
    }

    @GetMapping("blogs/view")
    public ModelAndView showAllBlogs (@ModelAttribute("Blogs") Blog blogs) {
        ModelAndView page = new ModelAndView("showBlogs");
        List<Blog> allBlogs = (List<Blog>) blogRepository.findAll();
        page.addObject("blogs", allBlogs);
        return page;
    }
}
